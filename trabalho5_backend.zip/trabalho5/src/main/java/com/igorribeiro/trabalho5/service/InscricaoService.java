package com.igorribeiro.trabalho5.service;
import com.igorribeiro.trabalho5.model.Aluno;
import com.igorribeiro.trabalho5.model.Inscricao;
import com.igorribeiro.trabalho5.repository.InscricaoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InscricaoService {
    private final InscricaoRepository inscricaoRepository;

    public InscricaoService(InscricaoRepository inscricaoRepository) {this.inscricaoRepository = inscricaoRepository;}

    public Inscricao cadastrarInscricao(Inscricao inscricao){return inscricaoRepository.save(inscricao);}

    public void removerInscricaoPorId(Long id){inscricaoRepository.deleteById(id);}

    public List<Inscricao> recuperarInscricoes() {
        return inscricaoRepository.findAll();
    }
    public List<Inscricao> recuperarInscricoesPorTurma(Long id){
        return inscricaoRepository.recuperarInscricoesPorTurma(id);
    }
    public Page<Inscricao> recuperarInscricoesPorTurmaComPaginacao(Pageable pageable, Long id){
        return inscricaoRepository.recuperarInscricoesPorTurmaComPaginacao(pageable, id);
    }


}
