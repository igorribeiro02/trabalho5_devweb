package com.igorribeiro.trabalho5.controller;
import com.igorribeiro.trabalho5.model.Aluno;
import com.igorribeiro.trabalho5.service.AlunoService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("alunos")   // htttp://localhost:8080/alunos
@CrossOrigin("http://localhost:5173")
public class AlunoController {
    private final AlunoService alunoService;

    @GetMapping
    public List<Aluno> recuperarAlunos() {
        return alunoService.recuperarAlunos();
    }

    @PostMapping
    public Aluno cadastrarAluno(@RequestBody Aluno aluno) {
        return alunoService.cadastrarAluno(aluno);
    }

    @PutMapping
    public Aluno alterarAluno(@RequestBody Aluno aluno) {
        return alunoService.alterarAluno(aluno);
    }

    @GetMapping("{idAluno}")
    public Aluno recuperarAlunoPorId(@PathVariable("idAluno")  Long id) {return alunoService.recuperarAlunoPorId(id);}


    // Implementação utilizando um builder
    // Delete para http://localhost:8080/produtos/1
    @DeleteMapping("{idAluno}")
    public ResponseEntity<Void> removerAlunoPorId(@PathVariable("idAluno") Long id) {
        alunoService.removerAlunoPorId(id);
        return ResponseEntity.ok().build();
    }
}