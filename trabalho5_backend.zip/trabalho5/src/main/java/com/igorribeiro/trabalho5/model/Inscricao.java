package com.igorribeiro.trabalho5.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import java.time.LocalDate;
@NoArgsConstructor
@Getter
@Setter
@ToString

@Entity
public class Inscricao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private LocalDate dataHora;


    @ManyToOne(fetch = FetchType.EAGER)
    private Aluno aluno;

    @ManyToOne(fetch = FetchType.EAGER)
    private Turma turma;

    public Inscricao(Turma turma, Aluno aluno, LocalDate dataHora) {
        this.turma = turma;
        this.aluno = aluno;
        this.dataHora = dataHora;
    }
}
