package com.igorribeiro.trabalho5.repository;

import com.igorribeiro.trabalho5.model.Disciplina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Long> {

}

