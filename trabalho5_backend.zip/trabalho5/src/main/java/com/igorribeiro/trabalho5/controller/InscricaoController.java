package com.igorribeiro.trabalho5.controller;


import com.igorribeiro.trabalho5.model.Aluno;
import com.igorribeiro.trabalho5.model.Inscricao;
import com.igorribeiro.trabalho5.model.ResultadoPaginado;
import com.igorribeiro.trabalho5.service.InscricaoService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("inscricoes")   // htttp://localhost:8080/inscricoes
@CrossOrigin("http://localhost:5173")
public class InscricaoController {
    private final InscricaoService inscricaoService;

    @PostMapping
    public Inscricao cadastrarInscricao(@RequestBody Inscricao inscrição){return inscricaoService.cadastrarInscricao(inscrição);}

    @DeleteMapping("{idInscricao}")
    public ResponseEntity<Void>  removerInscricaoPorId(@PathVariable("idInscricao") Long id)
    {inscricaoService.removerInscricaoPorId(id);
        return ResponseEntity.ok().build();}

    @GetMapping
    public List<Inscricao> recuperarInscricoes() {
        return inscricaoService.recuperarInscricoes();
    }
    @GetMapping("turma={idTurma}")
    public List<Inscricao> recuperarInscricoesPorTurma(@PathVariable("idTurma") Long id) {
        return inscricaoService.recuperarInscricoesPorTurma(id);
    }
    @GetMapping("paginacao")
    public ResultadoPaginado<Inscricao> recuperarInscricoesPorTurmaComPaginacao(@RequestParam(name="pagina", defaultValue = "0")int pagina, @RequestParam(name="tamanho", defaultValue = "5")int tamanho, @RequestParam(name="turma", defaultValue = "")Long turma){
        Pageable pageable = PageRequest.of(pagina, tamanho);
        Page<Inscricao> page = inscricaoService.recuperarInscricoesPorTurmaComPaginacao(pageable, turma);
        return new ResultadoPaginado<Inscricao>(page.getTotalElements(), page.getTotalPages(), page.getNumber(), page.getContent());
    }

}
