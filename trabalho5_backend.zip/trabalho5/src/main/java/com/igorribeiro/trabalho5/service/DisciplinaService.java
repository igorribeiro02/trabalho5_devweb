package com.igorribeiro.trabalho5.service;

import com.igorribeiro.trabalho5.model.Disciplina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.igorribeiro.trabalho5.repository.DisciplinaRepository;

@Service
public class DisciplinaService {
    @Autowired
    private DisciplinaRepository disciplinaRepository;

    public Disciplina cadastrarDisciplina(Disciplina disciplina){
        return disciplinaRepository.save(disciplina);
    }

}