package com.igorribeiro.trabalho5.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class Turma {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String codigo;
    private String ano;
    private String periodo;

    @ManyToOne(fetch = FetchType.EAGER)
    private Professor professor;

    @ManyToOne // eager é o default
    private Disciplina disciplina;

    public Turma(String ano, String periodo, Professor professor, Disciplina disciplina, String codigo) {
        this.ano = ano;
        this.periodo = periodo;
        this.professor = professor;
        this.disciplina = disciplina;
        this.codigo = codigo;
    }
}
