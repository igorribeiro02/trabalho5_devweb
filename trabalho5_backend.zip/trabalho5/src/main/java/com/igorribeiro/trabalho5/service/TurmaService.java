package com.igorribeiro.trabalho5.service;

import com.igorribeiro.trabalho5.exception.EntidadeNaoEncontradaException;
import com.igorribeiro.trabalho5.model.Aluno;
import com.igorribeiro.trabalho5.model.Inscricao;
import com.igorribeiro.trabalho5.model.Professor;
import com.igorribeiro.trabalho5.model.Turma;
import com.igorribeiro.trabalho5.repository.AlunoRepository;
import com.igorribeiro.trabalho5.repository.TurmaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TurmaService {

    private final TurmaRepository turmaRepository;


    public Turma recuperarTurmaPorId(Long id) {
        return turmaRepository.findById(id)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Aluno com id = " + id + " não encontrado."));
    }


    public TurmaService(TurmaRepository turmaRepository) {
        this.turmaRepository = turmaRepository;
    }

    public Turma cadastrarTurma(Turma turma){return turmaRepository.save(turma);}

    public void removerTurmaPorId(Long id){turmaRepository.deleteById(id);}

    public List<Turma> recuperarTodasTurmas() {
        return turmaRepository.findAll();
    }

}
