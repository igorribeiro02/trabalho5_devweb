package com.igorribeiro.trabalho5.repository;

import com.igorribeiro.trabalho5.model.Inscricao;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface InscricaoRepository extends JpaRepository<Inscricao, Long> {
    @Query("select i from Inscricao i where i.turma.id = :id")
    public List<Inscricao> recuperarInscricoesPorTurma(@Param("id")Long id);
    @Query(value="select i from Inscricao i where i.turma.id = :id order by i.aluno.nome", countQuery = "select count(i) from Inscricao i where i.turma.id = :id")
    Page<Inscricao> recuperarInscricoesPorTurmaComPaginacao(Pageable pageable, @Param("id")Long id);
}

