package com.igorribeiro.trabalho5.controller;

import com.igorribeiro.trabalho5.model.Disciplina;
import com.igorribeiro.trabalho5.service.DisciplinaService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("disciplinas")
@CrossOrigin("http://localhost:5173")
public class DisciplinaController {
    @Autowired
    private DisciplinaService disciplinaService;
    @PostMapping
    public Disciplina cadastrarDisciplina(@RequestBody Disciplina d){
        return disciplinaService.cadastrarDisciplina(d);
    }
}

